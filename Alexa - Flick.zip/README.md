# Alexa - Flick
> *Movies at your finger tip*

This skill let you know about the movies which are showing right now in your city as well as the movies which are about to show in your city.
The user is asked for the city, hence the user may request for movies showing in any city in India.

##### Features
- Tells the movies showing right now
- Tells the movies coming soon